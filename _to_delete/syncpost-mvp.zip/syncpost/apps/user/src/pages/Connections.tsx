import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ConnectedAccount, SocialPlatform } from '@syncpost/api-client';
import { api } from '../lib/api';

const PLATFORMS: { key: SocialPlatform; label: string }[] = [
  { key: 'LINKEDIN', label: 'LinkedIn' },
  { key: 'FACEBOOK', label: 'Facebook' },
  { key: 'X', label: 'X (Twitter)' },
];

export default function Connections() {
  const [accounts, setAccounts] = useState<ConnectedAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [params] = useSearchParams();

  async function load() {
    setLoading(true);
    const data = await api.get<ConnectedAccount[]>('/social/accounts');
    setAccounts(data);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function connect(platform: SocialPlatform) {
    const { url } = await api.get<{ url: string }>(`/social/${platform}/connect`);
    window.location.href = url;
  }

  async function disconnect(platform: SocialPlatform) {
    await api.delete(`/social/${platform}`);
    load();
  }

  const connectedError = params.get('error');
  const justConnected = params.get('connected');

  return (
    <div className="card">
      <h1>Connected accounts</h1>
      {justConnected && <p className="success">Connected {justConnected} successfully.</p>}
      {connectedError && <p className="error">{connectedError}</p>}
      {loading ? (
        <p>Loading...</p>
      ) : (
        <ul className="platform-list">
          {PLATFORMS.map((p) => {
            const connected = accounts.find((a) => a.platform === p.key);
            return (
              <li key={p.key}>
                <span>
                  <strong>{p.label}</strong>
                  {connected ? ` — connected as ${connected.platformUsername || connected.id}` : ' — not connected'}
                </span>
                {connected ? (
                  <button onClick={() => disconnect(p.key)}>Disconnect</button>
                ) : (
                  <button onClick={() => connect(p.key)}>Connect</button>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
