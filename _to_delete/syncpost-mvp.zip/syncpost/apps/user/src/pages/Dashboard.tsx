import { FormEvent, useEffect, useState } from 'react';
import { ApiError, ConnectedAccount, Post, SocialPlatform } from '@syncpost/api-client';
import { api } from '../lib/api';

const PLATFORMS: { key: SocialPlatform; label: string }[] = [
  { key: 'LINKEDIN', label: 'LinkedIn' },
  { key: 'FACEBOOK', label: 'Facebook' },
  { key: 'X', label: 'X (Twitter)' },
];

export default function Dashboard() {
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [selected, setSelected] = useState<SocialPlatform[]>([]);
  const [accounts, setAccounts] = useState<ConnectedAccount[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function loadAll() {
    const [accs, myPosts] = await Promise.all([
      api.get<ConnectedAccount[]>('/social/accounts'),
      api.get<Post[]>('/posts'),
    ]);
    setAccounts(accs);
    setPosts(myPosts);
  }

  useEffect(() => {
    loadAll();
  }, []);

  function togglePlatform(p: SocialPlatform) {
    setSelected((cur) => (cur.includes(p) ? cur.filter((x) => x !== p) : [...cur, p]));
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (selected.length === 0) {
      setError('Pick at least one connected platform to post to.');
      return;
    }
    setSubmitting(true);
    try {
      await api.post('/posts', { content, imageUrl: imageUrl || undefined, platforms: selected });
      setContent('');
      setImageUrl('');
      setSelected([]);
      await loadAll();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not publish this post');
    } finally {
      setSubmitting(false);
    }
  }

  const connectedPlatforms = new Set(accounts.map((a) => a.platform));

  return (
    <div>
      <div className="card">
        <h1>Create a post</h1>
        <form onSubmit={onSubmit}>
          <label>What do you want to share?</label>
          <textarea rows={5} value={content} onChange={(e) => setContent(e.target.value)} required />
          <label>Image URL (optional)</label>
          <input value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} placeholder="https://..." />
          <label>Publish to</label>
          <div className="platform-checkboxes">
            {PLATFORMS.map((p) => {
              const isConnected = connectedPlatforms.has(p.key);
              return (
                <label key={p.key} className={isConnected ? '' : 'disabled'}>
                  <input
                    type="checkbox"
                    disabled={!isConnected}
                    checked={selected.includes(p.key)}
                    onChange={() => togglePlatform(p.key)}
                  />
                  {p.label} {!isConnected && '(not connected)'}
                </label>
              );
            })}
          </div>
          {error && <p className="error">{error}</p>}
          <button type="submit" disabled={submitting}>
            {submitting ? 'Publishing...' : 'Publish now'}
          </button>
        </form>
      </div>

      <div className="card">
        <h2>Your posts</h2>
        {posts.length === 0 && <p>No posts yet.</p>}
        <ul className="post-list">
          {posts.map((post) => (
            <li key={post.id}>
              <p>{post.content}</p>
              <p className={`status status-${post.status.toLowerCase()}`}>{post.status}</p>
              <ul className="result-list">
                {post.results.map((r) => (
                  <li key={r.id}>
                    {r.platform}: {r.status} {r.error ? `— ${r.error}` : ''}
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
