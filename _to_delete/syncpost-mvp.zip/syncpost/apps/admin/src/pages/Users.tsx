import { FormEvent, useEffect, useState } from 'react';
import { AdminUser, ApiError, SubscriptionPlan, SubscriptionStatus } from '@syncpost/api-client';
import { api } from '../lib/api';

const PLANS: SubscriptionPlan[] = ['FREE', 'CREATOR', 'PROFESSIONAL', 'AGENCY'];
const STATUSES: SubscriptionStatus[] = ['ACTIVE', 'INACTIVE', 'EXPIRED'];

function GrantSubscriptionForm({ userItem, onUpdated }: { userItem: AdminUser; onUpdated: () => void }) {
  const [plan, setPlan] = useState<SubscriptionPlan>(userItem.subscription?.plan || 'FREE');
  const [status, setStatus] = useState<SubscriptionStatus>(userItem.subscription?.status || 'ACTIVE');
  const [postsLimit, setPostsLimit] = useState(userItem.subscription?.postsLimit ?? 20);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function save() {
    setSaving(true);
    setError(null);
    try {
      await api.patch(`/admin/users/${userItem.id}/subscription`, { plan, status, postsLimit });
      onUpdated();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not update subscription');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="grant-form">
      <select value={plan} onChange={(e) => setPlan(e.target.value as SubscriptionPlan)}>
        {PLANS.map((p) => (
          <option key={p} value={p}>
            {p}
          </option>
        ))}
      </select>
      <select value={status} onChange={(e) => setStatus(e.target.value as SubscriptionStatus)}>
        {STATUSES.map((s) => (
          <option key={s} value={s}>
            {s}
          </option>
        ))}
      </select>
      <input
        type="number"
        min={1}
        value={postsLimit}
        onChange={(e) => setPostsLimit(Number(e.target.value))}
        style={{ width: 80 }}
      />
      <button onClick={save} disabled={saving}>
        {saving ? 'Saving...' : 'Save access'}
      </button>
      {error && <p className="error">{error}</p>}
    </div>
  );
}

export default function Users() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [createError, setCreateError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  async function load() {
    setLoading(true);
    const data = await api.get<AdminUser[]>('/admin/users');
    setUsers(data);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function onCreate(e: FormEvent) {
    e.preventDefault();
    setCreateError(null);
    setCreating(true);
    try {
      await api.post('/admin/users', { name, email, password });
      setName('');
      setEmail('');
      setPassword('');
      setShowCreate(false);
      await load();
    } catch (err) {
      setCreateError(err instanceof ApiError ? err.message : 'Could not create user');
    } finally {
      setCreating(false);
    }
  }

  async function toggleActive(u: AdminUser) {
    await api.patch(`/admin/users/${u.id}/${u.isActive ? 'deactivate' : 'reactivate'}`);
    load();
  }

  return (
    <div className="card">
      <div className="card-header">
        <h1>Users</h1>
        <button onClick={() => setShowCreate((s) => !s)}>{showCreate ? 'Cancel' : '+ Create user'}</button>
      </div>

      {showCreate && (
        <form className="create-form" onSubmit={onCreate}>
          <input placeholder="Full name" value={name} onChange={(e) => setName(e.target.value)} required />
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Temporary password (min 8 chars)"
            minLength={8}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          {createError && <p className="error">{createError}</p>}
          <button type="submit" disabled={creating}>
            {creating ? 'Creating...' : 'Create with active FREE plan'}
          </button>
        </form>
      )}

      {loading ? (
        <p>Loading...</p>
      ) : (
        <table className="users-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Status</th>
              <th>Connected</th>
              <th>Subscription access</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td>
                  <button className="link-btn" onClick={() => toggleActive(u)}>
                    {u.isActive ? 'Active (click to disable)' : 'Disabled (click to enable)'}
                  </button>
                </td>
                <td>{u.socialAccounts.map((a) => a.platform).join(', ') || '—'}</td>
                <td>
                  <GrantSubscriptionForm userItem={u} onUpdated={load} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
