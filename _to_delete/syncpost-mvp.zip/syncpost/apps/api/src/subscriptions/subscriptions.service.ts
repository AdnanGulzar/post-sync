import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { PLAN_DEFINITIONS } from './plans';

@Injectable()
export class SubscriptionsService {
  constructor(private prisma: PrismaService) {}

  async getMySubscription(userId: string) {
    const subscription = await this.prisma.subscription.findUnique({ where: { userId } });
    return { subscription, plans: PLAN_DEFINITIONS };
  }

  /** Counts posts created in the current calendar month, used to enforce plan limits. */
  async countPostsThisMonth(userId: string) {
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0, 0, 0, 0);
    return this.prisma.post.count({ where: { userId, createdAt: { gte: startOfMonth } } });
  }
}
