export const PLAN_DEFINITIONS = {
  FREE: { label: 'Free', price: 0, postsLimit: 20, connectedAccountsLimit: 2 },
  CREATOR: { label: 'Creator', price: 15, postsLimit: Infinity, connectedAccountsLimit: 5 },
  PROFESSIONAL: { label: 'Professional', price: 49, postsLimit: Infinity, connectedAccountsLimit: 15 },
  AGENCY: { label: 'Agency', price: 199, postsLimit: Infinity, connectedAccountsLimit: 100 },
} as const;
