import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { SocialPlatform } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { OAuthStateService } from './oauth-state.service';
import { LinkedInService } from './linkedin.service';
import { FacebookService } from './facebook.service';
import { TwitterService } from './twitter.service';
import { SocialPlatformService, PublishResult } from './publisher.interface';

@Injectable()
export class SocialService {
  private services: Record<SocialPlatform, SocialPlatformService>;

  constructor(
    private prisma: PrismaService,
    private stateService: OAuthStateService,
    private linkedIn: LinkedInService,
    private facebook: FacebookService,
    private twitter: TwitterService,
  ) {
    this.services = {
      LINKEDIN: this.linkedIn,
      FACEBOOK: this.facebook,
      X: this.twitter,
    };
  }

  private serviceFor(platform: SocialPlatform): SocialPlatformService {
    const service = this.services[platform];
    if (!service) throw new BadRequestException(`Unsupported platform: ${platform}`);
    return service;
  }

  listAccounts(userId: string) {
    return this.prisma.socialAccount.findMany({
      where: { userId },
      select: { id: true, platform: true, platformUsername: true, connectedAt: true },
    });
  }

  getConnectUrl(userId: string, platform: SocialPlatform): string {
    const service = this.serviceFor(platform);
    let codeVerifier: string | undefined;
    if (platform === 'X') {
      codeVerifier = TwitterService.generateCodeVerifier();
    }
    const state = this.stateService.create(userId, platform, codeVerifier);
    return service.getAuthUrl(state, codeVerifier);
  }

  async handleCallback(platform: SocialPlatform, code: string, state: string) {
    const entry = this.stateService.consume(state);
    if (!entry || entry.platform !== platform) {
      throw new BadRequestException('Invalid or expired OAuth state. Please try connecting again.');
    }

    const service = this.serviceFor(platform);
    const result = await service.handleCallback(code, entry.codeVerifier);

    return this.prisma.socialAccount.upsert({
      where: { userId_platform: { userId: entry.userId, platform } },
      create: {
        userId: entry.userId,
        platform,
        platformUserId: result.platformUserId,
        platformUsername: result.platformUsername,
        accessToken: result.accessToken,
        refreshToken: result.refreshToken,
        tokenExpiresAt: result.tokenExpiresAt,
        metadata: (result.metadata as any) ?? undefined,
      },
      update: {
        platformUserId: result.platformUserId,
        platformUsername: result.platformUsername,
        accessToken: result.accessToken,
        refreshToken: result.refreshToken,
        tokenExpiresAt: result.tokenExpiresAt,
        metadata: (result.metadata as any) ?? undefined,
      },
    });
  }

  async disconnect(userId: string, platform: SocialPlatform) {
    const account = await this.prisma.socialAccount.findUnique({
      where: { userId_platform: { userId, platform } },
    });
    if (!account) throw new NotFoundException('No connected account for this platform');
    return this.prisma.socialAccount.delete({ where: { id: account.id } });
  }

  async publish(userId: string, platform: SocialPlatform, content: string, imageUrl?: string): Promise<PublishResult> {
    const account = await this.prisma.socialAccount.findUnique({
      where: { userId_platform: { userId, platform } },
    });
    if (!account) {
      throw new BadRequestException(`${platform} is not connected for this user`);
    }
    const service = this.serviceFor(platform);
    return service.publish(account, content, imageUrl);
  }
}
