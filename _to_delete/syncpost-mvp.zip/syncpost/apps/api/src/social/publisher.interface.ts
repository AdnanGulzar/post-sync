import { SocialAccount } from '@prisma/client';

export interface PublishResult {
  platformPostId: string;
}

export interface SocialPlatformService {
  /** Builds the provider's OAuth "authorize" URL the user's browser should be sent to. */
  getAuthUrl(state: string, codeVerifier?: string): string;

  /**
   * Exchanges the authorization `code` from the provider's redirect for tokens,
   * fetches the connecting account's basic profile, and returns everything
   * needed to persist a SocialAccount row.
   */
  handleCallback(
    code: string,
    codeVerifier?: string,
  ): Promise<{
    platformUserId: string;
    platformUsername?: string;
    accessToken: string;
    refreshToken?: string;
    tokenExpiresAt?: Date;
    metadata?: Record<string, unknown>;
  }>;

  /** Publishes `content` (and optional image) using a previously connected account. */
  publish(account: SocialAccount, content: string, imageUrl?: string): Promise<PublishResult>;
}
