import { BadRequestException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { SocialService } from '../social/social.service';
import { SubscriptionsService } from '../subscriptions/subscriptions.service';
import { PLAN_DEFINITIONS } from '../subscriptions/plans';
import { CreatePostDto } from './dto/create-post.dto';

@Injectable()
export class PostsService {
  constructor(
    private prisma: PrismaService,
    private socialService: SocialService,
    private subscriptionsService: SubscriptionsService,
  ) {}

  async listMine(userId: string) {
    return this.prisma.post.findMany({
      where: { userId },
      include: { results: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async createAndPublish(userId: string, dto: CreatePostDto) {
    const subscription = await this.prisma.subscription.findUnique({ where: { userId } });
    const plan = subscription ? PLAN_DEFINITIONS[subscription.plan] : PLAN_DEFINITIONS.FREE;
    const limit = subscription?.postsLimit ?? plan.postsLimit;

    if (Number.isFinite(limit)) {
      const usedThisMonth = await this.subscriptionsService.countPostsThisMonth(userId);
      if (usedThisMonth >= limit) {
        throw new BadRequestException(
          `You've reached your plan's limit of ${limit} posts this month. Ask your admin to upgrade your plan.`,
        );
      }
    }

    const post = await this.prisma.post.create({
      data: {
        userId,
        content: dto.content,
        imageUrl: dto.imageUrl,
        platforms: dto.platforms,
        status: 'PUBLISHING',
      },
    });

    const outcomes = await Promise.allSettled(
      dto.platforms.map((platform) => this.socialService.publish(userId, platform, dto.content, dto.imageUrl)),
    );

    await Promise.all(
      outcomes.map((outcome, i) => {
        const platform = dto.platforms[i];
        if (outcome.status === 'fulfilled') {
          return this.prisma.postPublishResult.upsert({
            where: { postId_platform: { postId: post.id, platform } },
            create: {
              postId: post.id,
              platform,
              status: 'SUCCESS',
              platformPostId: outcome.value.platformPostId,
              publishedAt: new Date(),
            },
            update: {
              status: 'SUCCESS',
              platformPostId: outcome.value.platformPostId,
              publishedAt: new Date(),
              error: null,
            },
          });
        }
        return this.prisma.postPublishResult.upsert({
          where: { postId_platform: { postId: post.id, platform } },
          create: {
            postId: post.id,
            platform,
            status: 'FAILED',
            error: outcome.reason?.message || 'Unknown error',
          },
          update: {
            status: 'FAILED',
            error: outcome.reason?.message || 'Unknown error',
          },
        });
      }),
    );

    const allSucceeded = outcomes.every((o) => o.status === 'fulfilled');
    const allFailed = outcomes.every((o) => o.status === 'rejected');
    const finalStatus = allSucceeded ? 'PUBLISHED' : allFailed ? 'FAILED' : 'PARTIAL';

    return this.prisma.post.update({
      where: { id: post.id },
      data: { status: finalStatus },
      include: { results: true },
    });
  }
}
