import { ArrayMinSize, IsArray, IsEnum, IsOptional, IsString, IsUrl, MinLength } from 'class-validator';
import { SocialPlatform } from '@prisma/client';

export class CreatePostDto {
  @IsString()
  @MinLength(1)
  content: string;

  @IsArray()
  @ArrayMinSize(1)
  @IsEnum(SocialPlatform, { each: true })
  platforms: SocialPlatform[];

  @IsOptional()
  @IsUrl()
  imageUrl?: string;
}
