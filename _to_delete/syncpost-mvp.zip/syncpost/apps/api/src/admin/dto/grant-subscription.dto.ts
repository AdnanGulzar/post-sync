import { IsEnum, IsInt, IsOptional, IsISO8601 } from 'class-validator';
import { SubscriptionPlan, SubscriptionStatus } from '@prisma/client';

export class GrantSubscriptionDto {
  @IsEnum(SubscriptionPlan)
  plan: SubscriptionPlan;

  @IsEnum(SubscriptionStatus)
  status: SubscriptionStatus;

  @IsOptional()
  @IsInt()
  postsLimit?: number;

  @IsOptional()
  @IsISO8601()
  endDate?: string;
}
