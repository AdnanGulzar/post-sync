import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../prisma/prisma.service';
import { CreateUserDto } from './dto/create-user.dto';
import { GrantSubscriptionDto } from './dto/grant-subscription.dto';

@Injectable()
export class AdminService {
  constructor(private prisma: PrismaService) {}

  async listUsers() {
    return this.prisma.user.findMany({
      where: { role: 'USER' },
      include: { subscription: true, socialAccounts: { select: { platform: true, connectedAt: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async createUser(adminId: string, dto: CreateUserDto) {
    const existing = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (existing) throw new ConflictException('An account with this email already exists');

    const passwordHash = await bcrypt.hash(dto.password, 12);

    return this.prisma.user.create({
      data: {
        email: dto.email,
        passwordHash,
        name: dto.name,
        role: 'USER',
        createdByAdminId: adminId,
        // Admin-created accounts are granted an active FREE subscription immediately,
        // since the admin is vouching for this user manually.
        subscription: { create: { plan: 'FREE', status: 'ACTIVE', postsLimit: 20 } },
      },
      include: { subscription: true },
    });
  }

  async grantSubscription(adminId: string, userId: string, dto: GrantSubscriptionDto) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new NotFoundException('User not found');

    return this.prisma.subscription.upsert({
      where: { userId },
      create: {
        userId,
        plan: dto.plan,
        status: dto.status,
        postsLimit: dto.postsLimit ?? 20,
        endDate: dto.endDate ? new Date(dto.endDate) : null,
        grantedByAdminId: adminId,
      },
      update: {
        plan: dto.plan,
        status: dto.status,
        postsLimit: dto.postsLimit ?? undefined,
        endDate: dto.endDate ? new Date(dto.endDate) : null,
        grantedByAdminId: adminId,
      },
    });
  }

  async deactivateUser(userId: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new NotFoundException('User not found');
    return this.prisma.user.update({ where: { id: userId }, data: { isActive: false } });
  }

  async reactivateUser(userId: string) {
    return this.prisma.user.update({ where: { id: userId }, data: { isActive: true } });
  }
}
