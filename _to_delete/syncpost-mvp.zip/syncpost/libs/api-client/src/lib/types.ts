export type Role = 'ADMIN' | 'USER';
export type SubscriptionPlan = 'FREE' | 'CREATOR' | 'PROFESSIONAL' | 'AGENCY';
export type SubscriptionStatus = 'ACTIVE' | 'INACTIVE' | 'EXPIRED';
export type SocialPlatform = 'LINKEDIN' | 'FACEBOOK' | 'X';
export type PostStatus = 'DRAFT' | 'PUBLISHING' | 'PUBLISHED' | 'FAILED' | 'PARTIAL';
export type PublishStatus = 'PENDING' | 'SUCCESS' | 'FAILED';

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: Role;
}

export interface AuthResponse {
  accessToken: string;
  user: AuthUser;
}

export interface Subscription {
  id: string;
  userId: string;
  plan: SubscriptionPlan;
  status: SubscriptionStatus;
  postsLimit: number;
  startDate: string;
  endDate: string | null;
}

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  isActive: boolean;
  createdAt: string;
  subscription: Subscription | null;
  socialAccounts: { platform: SocialPlatform; connectedAt: string }[];
}

export interface ConnectedAccount {
  id: string;
  platform: SocialPlatform;
  platformUsername: string | null;
  connectedAt: string;
}

export interface PostPublishResult {
  id: string;
  platform: SocialPlatform;
  status: PublishStatus;
  platformPostId: string | null;
  error: string | null;
}

export interface Post {
  id: string;
  content: string;
  imageUrl: string | null;
  platforms: SocialPlatform[];
  status: PostStatus;
  createdAt: string;
  results: PostPublishResult[];
}
